/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.aula14.modulos;

import javax.swing.JOptionPane;

/**
 *
 * @author diegomoraes
 */
public class Funcoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        
        
        mensagempar(soma(2, 4));
      
    }
    
    
    public static void mensagem(){
        
        JOptionPane.showMessageDialog(null,"Olá Mundo");
        
    }
    
    public static void mensagempar(int soma){
        
        JOptionPane.showMessageDialog(null,soma);
        
    }
    
    
    
    public static int soma(int x, int y){
                
        return x+y;
        
    }
    
}
