/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.aula18.recursaoebd;

/**
 *
 * @author diegomoraes
 */
public class FatorialRecursao {
    
    
    int fatorial(int num){

   
   if(num==0){
     
     return 1;

   }else{

     
     return num * fatorial(num-1);

   }


}
    
    
}
